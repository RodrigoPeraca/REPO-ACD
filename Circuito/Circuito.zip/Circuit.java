package Exercicios.Java.Circuito;

public abstract class Circuit {
    public abstract double getResistancia();
}
