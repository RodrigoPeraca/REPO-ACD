package Exercicios.Java.SuperM;
public enum FormaPagamento {
    DINHEIRO, CHEQUE, CARTAO
}
